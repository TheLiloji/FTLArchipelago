# FTL Archipelago 0.6 night build: what to test

Debug build (test keys on F10). Hyperspace 1.23.1, then the mod, then copy Hyperspace.dll into the FTL folder.
Base game: ArchipelagoFTL.ftl + ftl.apworld. Multiverse: FTLArchipelago-MV.ftl + ftl_mv.apworld (game "FTL Multiverse");
remove an old ftlmv.apworld from custom_worlds first.

New options (all off by default unless said):
- combat_checks_mode: per_sector (+ fights_per_sector 1-5, combat_checks above 0)
- event_checks 0-20 (default 5): "Archipelago Event N" locations, handed out by the relay and pirate events
- flagship_sabotage 0-5
- reactor_checks
- sector_skip
- Multiverse: magic_hat (by_group by default), multiverse_endings

Save profiles (new Hyperspace.dll): each seed and solo get their own save. The home screen has a "Saves" button.
A new seed asks to use its own save: FTL restarts on it, the old save is kept in the ap_profiles folder next to
FTL's saves, nothing is deleted.
