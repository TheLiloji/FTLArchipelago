# FTL Archipelago 0.6 beta.3: what to test

Thanks for testing! This is a beta: it can break, so don't use it for a real async yet.

## Install

Same as 0.5 (see the setup guide on GitHub), but with the files from this zip:

1. Put `ftl.apworld` in your Archipelago `custom_worlds` folder (replace the 0.5 one).
2. In ftlman: Hyperspace 1.23.1, then `ArchipelagoFTL.ftl` last, and Apply.
   For Multiverse: Hyperspace, the two Multiverse zips, then `ArchipelagoFTLMV.ftl`, and use `ftlmv.apworld` (game "FTL Multiverse").
3. Copy `Hyperspace.dll` from this zip into the FTL folder, after Apply.
4. Generate a new seed with this apworld and the YAML of your choice: the new 0.6 options only exist in a seed made with it.

This build has the debug keys turned on (see the end of this sheet), so you can skip around quickly.

When something looks wrong, send `FTL_HS.log` (in the FTL folder) right after it happens and say what you were doing.

## Fixed since beta.1 (please check these first)

- [ ] DeathLink: a crew member taken away by an event (the Engi virus) or turned into another race is not a death. A real death still is.
- [ ] TrapLink: when nobody else on the link has sent a trap yet this session, an Archipelago deal's trap always hits you (it used to vanish 2 times out of 3).
- [ ] The pirate package event only says how much the package is worth, never the item itself (every language).
- [ ] Buying a layout in one AP STORE and then something in another store right after: both go out, nothing is refunded as "this run does not count".
- [ ] Fights won while the connection was lost are sent when it comes back, even after a crash and a restart.
- [ ] Run Start Scrap: the "+N scrap" banner shows at the start of each new run (new run, restart after a game over, FTL relaunched then connected), and only once per run.
- [ ] Ships are named by their class everywhere (Federation Cruiser B), not by the Type A's name (Osprey B).
- [ ] The Hints list drops a hint as soon as you do that check yourself.
- [ ] The connect panel's check count never goes past 100 %.
- [ ] No augment shows a padlock in stores, Shield Charge Booster and Automated Re-loader included.
- [ ] Multiverse: a ship that starts without Oxygen but has a room for it (MV Augmented Cruiser, Lanius, Caretaker) is offered Oxygen for free in the start-of-run menu. Base ships are offered nothing.

## The full list from beta.1

Tick what you tried. "Didn't get to it" is fine too.

### Start of a run
- [ ] The start menu shows each weapon and drone's power, and its stats and description when you hover it.
- [ ] With `system_install`, when the systems you received don't all fit, the menu lets you pick which ones come aboard.
- [ ] Connect panel: arrows, Home, End, Delete move in the text, Ctrl+V pastes at the cursor, Ctrl+A selects, holding Backspace keeps deleting.

### Fights
- [ ] Accepting a surrender counts as a fight won.
- [ ] An enemy that jumps away does NOT count.
- [ ] Killing the whole enemy crew counts (holograms and drones aside).
- [ ] Fight checks: fights 1 to 4 count as sector 1 checks, 5 to 8 as sector 2, 9 and 10 as sector 3 (only changes the logic with strict sector logic).

### Traps (if traps are on)
- [ ] Hazard Trap: the next fight's beacon gets a nebula, ion storm, asteroids, sun or pulsar, gone after the fight.
- [ ] Anti-Ship Battery Trap: the next fight has a battery shooting at you, it powers down when the fight ends.
- [ ] Power Surge Trap: the next enemy gets a flagship-style surge (lighter in sectors 1 and 2).

### Stores and the Archipelago shop
- [ ] Buying a system you don't have the blueprint for is refused and refunded, even right after buying a system you do have, in the same store.
- [ ] Opening an AP STORE beacon hints its packages on the server (`shop_hints`, on by default).
- [ ] Shop packages show "Sphere 1" for the earliest ones, never "Sphere 0".

### Ships and options
- [ ] `early_ship_keys` (default 1): a second ship key shows up in your first checks.
- [ ] `layout_unlocks: independent`: a Type B or C can come without the A, the A is greyed out in the hangar until you get it.
- [ ] `layout_unlocks: progressive`: one key per layout, A then B then C.
- [ ] `event_beacons`: marked / important (default) / hidden changes which beacons say ARCHIPELAGO.
- [ ] `crew_names`: crew who join take the other players' slot names (default).
- [ ] `sector_logic: none` is the new name of `relaxed` (old YAMLs with `relaxed` still work).
- [ ] Systemsanity: no Install check for Engines, Oxygen, Piloting and Weapons any more.
- [ ] Crew checks: Engi, Zoltan, Mantis are expected around sector 3, Rock and Slug 4, Lanius 5.
- [ ] The options are now sorted in groups in the Options Creator and the YAML template.

### Multiplayer
- [ ] DeathLink: a hologram or temporary crew fading away is not a death.
- [ ] Universal Tracker works without your YAML (only on seeds made with this apworld).

### Solo mode
- [ ] Solo mode says it is a fixed demo seed, gives one item per check, and the shop doesn't run empty.

## Debug keys and console

This beta has the test keys built in. Press **F10** to arm them (a banner says so), F10 again to turn them off.
Keep them off when you type in the connect panel or the console, or letters will trigger them.

Once armed, during a run:
- **X**: ends the fight (the enemy is destroyed) and loads the FTL drive.
- **N**: opens the sector map, like at an exit beacon, to go to the next sector.
- **F3**: next sector (if nothing happens, use N or the exit beacon).
- **F2**: +200 scrap.
- **F1**: opens a normal store at this beacon.
- **C**: opens the Archipelago shop at this beacon.
- **F4**: writes the shop status in `FTL_HS.log`.
- **F9**: writes a full state report in `FTL_HS.log` (handy to send with a bug).
- **B**: writes the Archipelago events seen this run in the log. **V**: plays the Archipelago events one after the other (package relay, pirates, Zoltan toll, Slug...).
- **K**: simulates a DeathLink received. **G**: simulates fuel from Energy Link. **J**: simulates a TrapLink trap.
- **F11** / **F12**: really lose the run (hull to zero / whole crew killed), to test what a defeat sends.
- **S**: starts or stops solo mode (works at the main menu even without F10).

Hyperspace console: press **\\** (backslash) during a run. Useful commands:
- `loadevent EVENT_NAME` plays an event, for example `loadevent PIRATE` (a pirate fight) or
  `loadevent AP_EVT_HIJACK` (the pirate package event).
- `lua Hyperspace.ships.enemy:DamageHull(100, true)` destroys the enemy.
- If the console types in the wrong case (LUA instead of lua), type it with the case inverted.
- A command that fails or is very long (around 200 characters) can freeze the game: restart FTL then.

Commands typed while an event window is open are lost, close the window first.

The mod's own status commands write to FTL_HS.log, handy when you report something: `LUA apNetStatus()`, `LUA apShopStatus()`, `LUA apSystemStatus()`, `LUA apEventStatus()`, `LUA apDeathLinkStatus()`, `LUA apTrapLinkStatus()`.
