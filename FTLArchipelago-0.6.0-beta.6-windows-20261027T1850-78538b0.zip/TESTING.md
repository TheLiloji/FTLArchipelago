# FTL Archipelago 0.6 beta.6: what to test

Thanks for testing! This is a beta: it can break, so don't use it for a real async yet.

## Install

Same as 0.5 (see the setup guide on GitHub), but with the files from this zip:

1. Put `ftl.apworld` in your Archipelago `custom_worlds` folder (replace the 0.5 one). For Multiverse, use `ftl_mv.apworld` (game "FTL Multiverse") and remove any old `ftlmv.apworld`, or Archipelago sees the game twice.
2. In ftlman: Hyperspace 1.23.1, then `ArchipelagoFTL.ftl` last, and Apply.
   For Multiverse: Hyperspace, the two Multiverse zips, then `FTLArchipelago-MV.ftl`, and use `ftl_mv.apworld` (game "FTL Multiverse").
3. Copy `Hyperspace.dll` from this zip into the FTL folder, after Apply. Same file as beta.4: if you already copied that one, nothing to do.
4. Generate a new seed with this apworld and the YAML of your choice: the new 0.6 options only exist in a seed made with it.

This build has the debug keys turned on (see the end of this sheet), so you can skip around quickly.

When something looks wrong, send `FTL_HS.log` (in the FTL folder) right after it happens and say what you were doing.

## New in beta.6 (please try these)

- [ ] TAB > overview: the EnergyLink chip shows how much fuel is in the shared pool ("EnergyLink: 12 fuel"). It shows "?" until the server answers, then updates every 20 seconds.
- [ ] `sector_skip`: if you don't take the offered exit and jump elsewhere, the offer is gone for the rest of the sector, and no other beacon turns into an exit. The extra pick ends when you close the menu, even if nothing fit, so it no longer comes back at every beacon.
- [ ] `event_checks` above 0: every sector has at least one Archipelago event beacon (the relay or the pirates). Needs a new seed made with this apworld.
- [ ] `sector_locks` with the shop by sector: a shared shop slot past sector 4 needs a ship you actually have, with its Sector Pass.

## New in beta.5

From your beta.4 feedback:
- [ ] TAB > Checks: the blue "in logic" line now follows the seed's logic: System Install checks only when you have the blueprint and the ship has room, crew checks too, Sector Passes per layout. A ship you haven't received shows none.
- [ ] `sector_skip`: the offered first beacon really is an exit now, jumping on at once gives 60 scrap (was 30) and one more pick in the start-of-run menu.
- [ ] Fight traps (Hazard, Anti-Ship Battery, Power Surge) armed when a run ends stay armed for the first fight of the next run.
- [ ] TrapLink: Archipelago never says who is on the link, so a partner only counts for 10 minutes after their last trap reached you, and is forgotten on a disconnect. Otherwise a deal's trap, and now the "another world" surge too, hits you, and the message says so.
- [ ] The AP STORE beacon is placed first in every sector, so busy sectors keep it (Multiverse nebulas like Hektar or the Spectral sectors used to lose it 2 times out of 3).

Multiverse:
- [ ] The long secret sectors (Hektar, Augmented, Royal, Ancient, Spider, Nights...) now have an AP STORE too. The one-beacon ones and the final showdown don't.

## New in beta.4

Save profiles (needs the new Hyperspace.dll):
- [ ] Each seed, and solo mode, gets its own FTL save. Connecting to another seed asks "Use its own save": FTL restarts on a fresh save, the old one is kept in the `ap_profiles` folder next to FTL's saves. Nothing is ever deleted.
- [ ] The home screen has a "Saves" button: the list shows each save (slot, checks, last played). Load one (FTL restarts on it) or archive one (asks first, moves it to `ap_profiles/archived`).
- [ ] "No, keep" on the question leaves the other seed out: this save stays as it is.

New options (all off by default unless said):
- [ ] `combat_checks_mode: per_sector` with `fights_per_sector` (1-5, default 2): the first fights of each sector send their own checks (needs Combat Checks per Ship above 0).
- [ ] `event_checks` (0-20, default 5): the relay and pirate events hand out their own "Archipelago Event N" checks before the shop's packages.
- [ ] `reactor_checks`: reactor power 10, 15, 20 and 25 send checks.
- [ ] `flagship_sabotage` (0-5): each Flagship phase arrives weakened.
- [ ] `sector_skip`: a layout that already got further may skip sectors 1 to 4, their first beacon is an exit and jumping on at once gives 60 scrap and one more pick.
- [ ] `sector_locks`: two Sector Passes per layout, the exits of sectors 4 and 7 stay shut until they come in.
- [ ] `shop_deal_scrap` (0-200 %, default 100): what the shop's deals pay, 0 turns them off.
- [ ] `kestrel_key`: when you don't start with the Kestrel, the Kestrel A needs its key too.
- [ ] TAB > Checks: a blue line on a check that is "in logic" with what you received.
- [ ] Two new events: an Engi overclock bet (Engi and civilian sectors) and a rare arms dealer (pirate sectors).

Multiverse:
- [ ] `magic_hat` (by_group by default, by_sector, disabled): Magic Hat items. Once one is received, the sector sheet in hyperspeed offers "Reroute." then "Use the Archipelago Magic Hat". Based on ArchiHat by Trapper444.
- [ ] `multiverse_endings`: the Flagship and the true ending send checks; Nexus, HER, The One Who Rhymes, Chaos and the royal heist hold filler only.
- [ ] `multiverse_quests`: finishing the quest that unlocks a Multiverse ship sends that ship's check (filler only).
- [ ] Ships without oxygen get it offered for free in the start-of-run menu.

## Fixed in beta.2 and beta.3

- [ ] DeathLink: a crew member taken away by an event (the Engi virus) or turned into another race is not a death. A real death still is.
- [ ] TrapLink: with nobody seen on the link, an Archipelago deal's trap hits you (it used to vanish 2 times out of 3).
- [ ] The pirate package event only says how much the package is worth, never the item itself (every language).
- [ ] Buying a layout in one AP STORE and then something in another store right after: both go out, nothing is refunded as "this run does not count".
- [ ] Fights won while the connection was lost are sent when it comes back, even after a crash and a restart.
- [ ] Run Start Scrap: the "+N scrap" banner shows at the start of each new run (new run, restart after a game over, FTL relaunched then connected), and only once per run.
- [ ] Ships are named by their class everywhere (Federation Cruiser B), not by the Type A's name (Osprey B).
- [ ] The Hints list drops a hint as soon as you do that check yourself.
- [ ] The connect panel's check count never goes past 100 %.
- [ ] No augment shows a padlock in stores, Shield Charge Booster and Automated Re-loader included.
- [ ] Multiverse: a ship that starts without Oxygen but has a room for it (MV Augmented Cruiser, Lanius, Caretaker) is offered Oxygen for free in the start-of-run menu. Base ships are offered nothing.

## The full list from beta.1

Tick what you tried. "Didn't get to it" is fine too.

### Start of a run
- [ ] The start menu shows each weapon and drone's power, and its stats and description when you hover it.
- [ ] With `system_install`, when the systems you received don't all fit, the menu lets you pick which ones come aboard.
- [ ] Connect panel: arrows, Home, End, Delete move in the text, Ctrl+V pastes at the cursor, Ctrl+A selects, holding Backspace keeps deleting.

### Fights
- [ ] Accepting a surrender counts as a fight won.
- [ ] An enemy that jumps away does NOT count.
- [ ] Killing the whole enemy crew counts (holograms and drones aside).
- [ ] Fight checks: fights 1 to 4 count as sector 1 checks, 5 to 8 as sector 2, 9 and 10 as sector 3 (only changes the logic with strict sector logic).

### Traps (if traps are on)
- [ ] Hazard Trap: the next fight's beacon gets a nebula, ion storm, asteroids, sun or pulsar, gone after the fight.
- [ ] Anti-Ship Battery Trap: the next fight has a battery shooting at you, it powers down when the fight ends.
- [ ] Power Surge Trap: the next enemy gets a flagship-style surge (lighter in sectors 1 and 2).

### Stores and the Archipelago shop
- [ ] Buying a system you don't have the blueprint for is refused and refunded, even right after buying a system you do have, in the same store.
- [ ] Opening an AP STORE beacon hints its packages on the server (`shop_hints`, on by default).
- [ ] Shop packages show "Sphere 1" for the earliest ones, never "Sphere 0".

### Ships and options
- [ ] `early_ship_keys` (default 1): a second ship key shows up in your first checks.
- [ ] `layout_unlocks: independent`: a Type B or C can come without the A, the A is greyed out in the hangar until you get it.
- [ ] `layout_unlocks: progressive`: one key per layout, A then B then C.
- [ ] `event_beacons`: marked / important (default) / hidden changes which beacons say ARCHIPELAGO.
- [ ] `crew_names`: crew who join take the other players' slot names (default).
- [ ] `sector_logic: none` is the new name of `relaxed` (old YAMLs with `relaxed` still work).
- [ ] Systemsanity: no Install check for Engines, Oxygen, Piloting and Weapons any more.
- [ ] Crew checks: Engi, Zoltan, Mantis are expected around sector 3, Rock and Slug 4, Lanius 5.
- [ ] The options are now sorted in groups in the Options Creator and the YAML template.

### Multiplayer
- [ ] DeathLink: a hologram or temporary crew fading away is not a death.
- [ ] Universal Tracker works without your YAML (only on seeds made with this apworld).

### Solo mode
- [ ] Solo mode says it is a fixed demo seed, gives one item per check, and the shop doesn't run empty.

## Debug keys and console

This beta has the test keys built in. Press **F10** to arm them (a banner says so), F10 again to turn them off.
Keep them off when you type in the connect panel or the console, or letters will trigger them.

Once armed, during a run:
- **X**: ends the fight (the enemy is destroyed) and loads the FTL drive.
- **N**: opens the sector map, like at an exit beacon, to go to the next sector.
- **F3**: next sector (if nothing happens, use N or the exit beacon).
- **F2**: +200 scrap.
- **F1**: opens a normal store at this beacon.
- **C**: opens the Archipelago shop at this beacon.
- **F4**: writes the shop status in `FTL_HS.log`.
- **F9**: writes a full state report in `FTL_HS.log` (handy to send with a bug).
- **B**: writes the Archipelago events seen this run in the log. **V**: plays the Archipelago events one after the other (package relay, pirates, Zoltan toll, Slug...).
- **K**: simulates a DeathLink received. **G**: simulates fuel from Energy Link. **J**: simulates a TrapLink trap.
- **F11** / **F12**: really lose the run (hull to zero / whole crew killed), to test what a defeat sends.
- **S**: starts or stops solo mode (works at the main menu even without F10).

Hyperspace console: press **\\** (backslash) during a run. Useful commands:
- `loadevent EVENT_NAME` plays an event, for example `loadevent PIRATE` (a pirate fight) or
  `loadevent AP_EVT_HIJACK` (the pirate package event).
- `lua Hyperspace.ships.enemy:DamageHull(100, true)` destroys the enemy.
- If the console types in the wrong case (LUA instead of lua), type it with the case inverted.
- A command that fails or is very long (around 200 characters) can freeze the game: restart FTL then.

Commands typed while an event window is open are lost, close the window first.

The mod's own status commands write to FTL_HS.log, handy when you report something: `LUA apNetStatus()`, `LUA apShopStatus()`, `LUA apSystemStatus()`, `LUA apEventStatus()`, `LUA apDeathLinkStatus()`, `LUA apTrapLinkStatus()`.
